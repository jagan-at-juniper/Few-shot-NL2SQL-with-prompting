package com.mist.sandbox;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;

import static org.ojalgo.function.PrimitiveFunction.DIVIDE;

public class ONS_test1 {
    public static void main(String[] args) throws Exception {
        System.out.println("Getting data ...");
        ArrayList<Double> data = get_data("setting1_seq_d0.json");
        System.out.println("Got data: " + data);

        int mk = 10;
        Double lrate = 1.75D;
        Double epsilon = Math.pow(10, -3);

        PhysicalStore.Factory<Double, PrimitiveDenseStore> storeFactory = PrimitiveDenseStore.FACTORY;
        PrimitiveDenseStore w = storeFactory.makeZero(1, mk);
        for (int i=0; i < mk; i++) w.set(i, 0.1D);

        ArrayList<Double> list = new ArrayList();
        Double SE = 0.0D;

        PrimitiveDenseStore A_trans = storeFactory.makeEye(mk, mk);
        A_trans.multiply(epsilon);

        PrimitiveDenseStore window = storeFactory.makeZero(1, mk);

        for (int i=mk; i < data.size(); i++) {
            int window_idx = 0;
            for (int j=i-mk; j < i; j++) window.set(window_idx++, data.get(j)); // load the window

            // prediction = w * data(i-mk:i-1)' # scalar: next prediction
            Double prediction = w.multiply(window.transpose()).doubleValue(0, 0);

            // diff = prediction - data(i); # scalar: absolute error
            Double diff = prediction - data.get(i);

            // grad = 2 * data(i-mk:i-1) * diff; # row vector: gradient?
            MatrixStore grad = window.multiply(2.0D).multiply(diff); // row vector: gradient?

            // A_trans = A_trans - A_trans * grad' * grad * A_trans/(1 + grad * A_trans * grad')
            PrimitiveDenseStore A_trans_div = A_trans.copy(); // copy because we modify A_trans in place for A_trans_div
            // A_trans_div = A_trans/(1 + grad * A_trans * grad') from the equation above
            A_trans_div.modifyAll(DIVIDE.second(1.0D + grad.multiply(A_trans).multiply(grad.transpose()).doubleValue(0, 0)));
            A_trans = (PrimitiveDenseStore)A_trans.subtract(A_trans.multiply(grad.transpose()).multiply(grad).multiply(A_trans_div));

            // w = w - lrate * grad * A_trans ; # update weights
            w = (PrimitiveDenseStore)w.subtract(A_trans.multiply(grad).multiply(lrate));

            list.add(diff);

            // SE = SE + diff^2; # squared error
            SE += Math.pow(diff, 2);

            // MSE = SE / i
            Double MSE = SE / list.size();

            // rMSE = sqrt(MSE)
            Double RMSE = Math.sqrt(MSE);

            Double window_SE = 0.0D;
            Double window_RMSE = 0.0D;
            if (list.size() > mk) {
                for (int wi = list.size() - mk; wi < list.size(); wi++) {
                    window_SE += Math.pow(list.get(wi), 2);
                }
                window_RMSE = Math.sqrt(window_SE / mk);
            }

            System.out.println("real = " + data.get(i) + ", prediction = " + prediction + ", diff = " + diff + ", whole RMSE = " + RMSE + ", window RMSE = " + window_RMSE);
        }

        System.out.println("Max diff = " + Collections.max(list));
        Double diffsum = 0.0D;
        for (Double diff:list) diffsum += diff;
        Double meandiff = diffsum / list.size();
        System.out.println("Mean diff = " + meandiff);
    }

    @SuppressWarnings("unchecked")
    private static ArrayList<Double> get_data(String filename) {
        try {
            JSONParser parser = new JSONParser();
            JSONObject jsonObject = (JSONObject) parser.parse(new FileReader(
                    "C:/Users/rcrowe/Documents/repos/ojAlgo_Test1/src/main/java/com/mist/sandbox/" + filename));
            return (ArrayList<Double>)jsonObject.get("data");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
